<?php
	$url = "index";
	header("Location:".$url."");
	exit;  
?>